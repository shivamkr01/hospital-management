# hospitals_management
Hospital management website
